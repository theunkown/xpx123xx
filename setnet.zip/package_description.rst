
This is the python library for Netmaxiot Pi, which is an open source platform for connecting Netmaxiot Sensors  to the Raspberry Pi.

Please visit:

   * Our `github repo folder https://github.com/Netmaxiot
   * Or our `official page https://www.netmax.co.in/Netmaxiotpi
   For more details about this platform.
